1. Class Diagram
2. Architecture
3. Comments
4. Sample solution for retweet
5. Slides about design pattern
