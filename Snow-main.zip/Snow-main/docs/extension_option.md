# Possible Extensions
1. Retweet (Required)
2. Topics
3. Remove file duplicates
4. Fediverse (Difficult)
5. ...
