package com.youtubegroup.Youtube.Project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YoutubeProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
